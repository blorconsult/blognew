import { Component, Input, OnInit } from '@angular/core';
import { BlockingProxy } from 'blocking-proxy';
import { PostListItemComponentComponent } from '../post-list-item-component/post-list-item-component.component';


@Component({
  selector: 'app-post-list-component',
  templateUrl: './post-list-component.component.html',
  styleUrls: ['./post-list-component.component.css']
})
export class PostListComponentComponent implements OnInit {

  @Input() post : PostListItemComponentComponent;
  
  constructor() {}

  ngOnInit() {
  }
}
