import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-post-list-item-component',
  templateUrl: './post-list-item-component.component.html',
  styleUrls: ['./post-list-item-component.component.css']
})
export class PostListItemComponentComponent implements OnInit {

  @Input() postTitle: string;
  @Input() postContent: string;
  @Input() postLoveIts: number;
  @Input() postCreatedAt: string;
  

  constructor() { }

  ngOnInit() {
  }

  onIncrement () {
    this.postLoveIts = this.postLoveIts +1;
    console.log(this.postLoveIts);
    return this.postLoveIts;

  }

  onDecrement () {
    this.postLoveIts = this.postLoveIts -1;
    console.log(this.postLoveIts);
    return this.postLoveIts;

  }

  getLoveIts () {
    return this.postLoveIts;
  }

  getBackgrounfColor() {

    if(this.postLoveIts <= 0) {

      return 'red';

    } else if(this.postLoveIts > 0) {

      return 'green';

    }

  }

  getColor() {

    if(this.postLoveIts <= 0) {

      return 'orange';

    } else if(this.postLoveIts > 0) {

      return 'green';

    }
  }
  


 

}
